import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const App = () => {
  const [numero1, setNumero1] = useState('');
  const [numero2, setNumero2] = useState('');
  const [resultado, setResultado] = useState(null);

  const somar = () => {
    setResultado(parseFloat(numero1) + parseFloat(numero2));
  };

  const subtrair = () => {
    setResultado(parseFloat(numero1) - parseFloat(numero2));
  };

  const multiplicar = () => {
    setResultado(parseFloat(numero1) * parseFloat(numero2));
  };

  const dividir = () => {
    if (parseFloat(numero2) !== 0) {
      setResultado(parseFloat(numero1) / parseFloat(numero2));
    } else {
      alert('Não é possível dividir por zero!');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Calculadora Simples</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o primeiro número"
        keyboardType="numeric"
        value={numero1}
        onChangeText={setNumero1}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite o segundo número"
        keyboardType="numeric"
        value={numero2}
        onChangeText={setNumero2}
      />
      <View style={styles.botoesContainer}>
        <Button title="Somar" onPress={somar} />
        <Button title="Subtrair" onPress={subtrair} />
        <Button title="Multiplicar" onPress={multiplicar} />
        <Button title="Dividir" onPress={dividir} />
      </View>
      {resultado !== null && (
        <Text style={styles.resultado}>Resultado: {resultado}</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#F5F5F5',
  },
  titulo: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    paddingHorizontal: 10,
    width: '100%',
  },
  botoesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 20,
  },
  resultado: {
    fontSize: 20,
    marginTop: 20,
  },
});

export default App;