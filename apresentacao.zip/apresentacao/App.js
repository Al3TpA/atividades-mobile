import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.paragrafo}>
        Meu nome é Alexandre, tenho 16 anos, faço aniversário no dia 6 de agosto, e eu sou um estudante de Desenvolvimento de Sistemas na Etec Adolpho Berezin, eu gosto de jogar alguns jogos online e de praticar esportes, além de tocar violão, Deus é bom e o Diabo não presta, amém.
      </Text>
      <Image
        source={require('./assets/midia.jpg')}
        style={styles.imagem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#F5F5F5',
  },
  paragrafo: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  imagem: {
    width: 110,
    height: 150,
  },
});

export default App;